﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace zd1_2_Marunenko
{
    public partial class Form1 : Form
    {
        Shop shop = new Shop();
        Product product;
        public Form1()
        {
            InitializeComponent();
        }
        //метод для обновления списка товаров
        private void UpdateProductList()
        {
            checkedListBox1.Items.Clear();
            foreach (var product in shop.GetAllProducts())
            {
                checkedListBox1.Items.Add(product.Name);
            }
        }
        private void button1_Click_1(object sender, EventArgs e) // Обработчик события нажатия кнопки для начала создания продукта
        {
            //проверка на пустое поле
            if (textBox13.Text == "")
            {
                MessageBox.Show("Заполните поле название продукта");
                return;


            }

            string name = textBox13.Text;

            //проверка, что только буквы
            bool onlyLetters = true;
            foreach (var ch in name)
            {
                if (!char.IsLetter(ch))
                {
                    onlyLetters = false;
                    break;
                }
            }

            if (!onlyLetters)
            {
                MessageBox.Show("Только буквы!!!");
                return;


            }
            name = char.ToUpper(name[0]) + name.Substring(1).ToLower();
            double price = Convert.ToDouble(numericUpDown3.Value);
            int quantity = Convert.ToInt32(numericUpDown4.Value);
            shop.CreateProduct(name, price, quantity);
            shop.WriteAllProducts();
            UpdateProductList();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int product = Convert.ToInt32(numericUpDown2.Value);
            foreach (var item in checkedListBox1.CheckedItems)
            {
                string produc = item.ToString();
                shop.Sell(produc, product);
            }
        }
        private void button9_Click(object sender, EventArgs e)
        {
            int product = Convert.ToInt32(numericUpDown3.Value);
            foreach (var item in checkedListBox1.CheckedItems)
            {
                string produc = item.ToString();
                shop.PopolnProduct(produc, product);
            }
        }









        PlayList playlist = new PlayList();
        Song song = new Song();
        private void UpdateSong()
        {
            song = playlist.CurrentSong();
            label7.Text = song.Author;
            label8.Text = song.Title;
            label9.Text = song.Filename;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox12.Text != "" && textBox11.Text != "" && textBox10.Text != "")//проверка, что все поля заполнены
            {
                string author, name, filename;
                author = textBox12.Text;
                name = textBox11.Text;
                filename = textBox10.Text;
                playlist.AddSong(author, name, filename);
                textBox12.ResetText();
                textBox11.ResetText();
                textBox10.ResetText();
                MessageBox.Show("Песня добавлена");
                playlist.GoToStart();
                UpdateSong();
            }
            else
            {
                MessageBox.Show("Заполните пожалуйста поля");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            playlist.GoToSong(Convert.ToInt32(numericUpDown1.Value));
            UpdateSong();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            playlist.Remove(Convert.ToInt32(numericUpDown2.Value));
            UpdateSong();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            playlist.Perexodtwo();
            song = playlist.CurrentSong();
            label7.Text = song.Author;
            label8.Text = song.Title;
            label9.Text = song.Filename;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            playlist.Perexodone();
            song = playlist.CurrentSong();
            label7.Text = song.Author;
            label8.Text = song.Title;
            label9.Text = song.Filename;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox9.Text != "" && textBox8.Text != "" && textBox7.Text != "")//проверка, что все поля заполнены
            {
                playlist.Remove(song);
                UpdateSong();
                textBox9.ResetText();
                textBox8.ResetText();
                textBox7.ResetText();
            }
            else
            {
                MessageBox.Show("Заполните поля");
            }
        }

        
    }
}
